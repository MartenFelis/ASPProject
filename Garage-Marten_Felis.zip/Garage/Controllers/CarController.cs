﻿using System.Collections.Generic;
using System.Linq;
using Garage.Entities;
using Garage.Models;
using Garage.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Bibliotheek.Controllers
{
    public class CarController : Controller
    {
        private readonly MyCarService _carService;

        public CarController(MyCarService carService)
        {
            _carService = carService;
        }

        [HttpGet("/cars")]
        public IActionResult Index()
        {
            var model = new CarListViewModel {Books = new List<CarDetailViewModel>()};
            var allCars = _carService.GetAllCars();
            model.Cars.AddRange(allCars.Select(ConvertCarToCarDetailViewModel).ToList());
            return View(model);
        }

        [HttpGet("/api/car")]
        public IActionResult IndexAsJson()
        {
            var model = new CarListViewModel { Cars = new List<CarDetailViewModel>() };
            var allCars = _carService.GetAllCars();
            model.Cars.AddRange(allCars.Select(ConvertCarToCarDetailViewModel).ToList());
            return new JsonResult(model);
        }

        protected CarDetailViewModel ConvertCarToCarDetailViewModel(Car car)
        {
            return new CarDetailViewModel()
            {
                Id = car.Id,
                Title = car.Title,
                CreationDate = car.CreationDate,
                Author = string.Join(";", car.Authors.Select(x => x.Author.FullName)),
                Genre = car.Genre?.Name,
                ISBN = car.ISBN
            };
        }


        [HttpGet("/cars/{id}")]
        public IActionResult Detail([FromRoute] int id)
        {
            var car = _carService.GetCarById(id);
            if (car == null)
            {
                return NotFound();
            }

            var vm = ConvertCarToEditDetailViewModel(car);
            vm.Genres = _carService.GetAllGenres().Select(x => new SelectListItem
                {
                    Text = x.Name,
                    Value = x.Id.ToString(),
                }
            ).ToList();
            return View(vm);
        }


        [HttpPost("/cars")]
        public IActionResult Persist([FromForm] CarEditDetailViewModel vm)
        {
            if (ModelState.IsValid)
            {
                var car = vm.Id == 0 ? new Car() : _carService.GetCarById(vm.Id);
                car.Title = vm.Title;
                car.Genre = vm.GenreId.HasValue ? _carService.GetGenreById(vm.GenreId.Value) : null;
                car.CreationDate = vm.CreationDate;
                car.ISBN = vm.ISBN;
                _carService.Persist(car);

                return Redirect("/cars");
            }
            return View("Detail", vm);
        }


        public BookEditDetailViewModel ConvertBookToEditDetailViewModel(Book book)
        {
            var vm = new BookEditDetailViewModel
            {
                Id = book.Id,
                Title = book.Title,
                CreationDate = book.CreationDate,
                Genre = book.Genre?.Name,
                GenreId = book.Genre?.Id
            };
            return vm;
        }

        [HttpPost("/books/delete/{id}")]
        public IActionResult Delete([FromRoute] int id)
        {
            _bookService.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}