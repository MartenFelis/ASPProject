﻿namespace Bibliotheek.Entities
{
    public class AuthorBook
    {
        public int BookId { get; set; }
        public car Book { get; set; }
        public int AuthorId { get; set; }
        public Author Author { get; set; }
    }
}