using System;
using System.Collections.Generic;

namespace Bibliotheek.Models
{
    public class CarListViewModel
    {
        public List<CarDetailViewModel> Books { get; set; }
        public DateTime GeneratedAt => DateTime.Now;
    }
}