﻿using System.Collections.Generic;
using Bibliotheek.Entities;

namespace Bibliotheek.Services
{
    public interface IBookService
    {
        List<car> GetAllBooks();
        car GetBookById(int id);
        List<Genre> GetAllGenres();
        Genre GetGenreById(int id);
        void Persist(car book);
        void Delete(int id);
    }
}