using System.Collections.Generic;
using Garage.Controllers;
using Garage.Controllers;
using Garage.Entities;
using Garage.Services;
using Moq;
using Xunit;

namespace Garage.UnitTests
{
    public class CarControllerTests
    {
        private readonly CarController _controller;
        private readonly Mock<MyCarService> _bookService = new Mock<MyCarService>(MockBehavior.Strict);

        public CarControllerTests()
        {
            _controller = new CarController(_bookService.Object);
        }

        [Fact]
        public void WeCanConvertABookToAViewModel()
        {
            var goingIn = new car()
            {
                Genre = new Genre {Name = "Genre"},
                ISBN = "abc",
                Title = "titel",
                Authors = new List<AuthorBook>
                {
                    new AuthorBook {Author = new Author {FirstName = "ABC", LastName = "CDE"}}
                }
            };
            var comingOut = _controller.ConvertBookToEditDetailViewModel(goingIn);
            Assert.Equal("Genre", comingOut.Genre);
            //TODO: check the other properties
            
        }

        [Fact]
        public void WeCanConvertABookToAViewModelWithMultipleAuthors()
        {
            //TODO what the method name says.
        }

        //TODO create a test for ConvertBookToBookDetailViewModel
        }
}